#pragma once

#include "settings.h"

extern HFont esp_font;

namespace Fonts
{
	void SetupFonts();
}