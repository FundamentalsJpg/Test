#pragma once
#include "../atgui.h"
namespace Walk
{
	extern bool showWindow;

	extern void RenderWindow();
}
