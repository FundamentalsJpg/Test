#pragma once

#include "../atgui.h"

namespace Configs
{
	extern bool showWindow;

	extern void RenderWindow();
}