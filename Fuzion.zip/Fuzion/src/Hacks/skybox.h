#pragma once

#include "../interfaces.h"
#include "../settings.h"

namespace SkyBox
{
	//Hooks
	void FrameStageNotify(ClientFrameStage_t stage);
}
