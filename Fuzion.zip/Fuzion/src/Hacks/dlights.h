#pragma once

#include "../settings.h"
#include "../interfaces.h"

namespace Dlights
{
	//Hooks
	void Paint();
}
