#pragma once

#include "../interfaces.h"
#include "../settings.h"

namespace SniperCrosshair
{

	//Hooks
	void Paint();
};
