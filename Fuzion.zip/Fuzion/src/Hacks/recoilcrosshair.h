#pragma once

#include "../settings.h"
#include "../Utils/draw.h"
#include "../interfaces.h"

namespace Recoilcrosshair
{
	//Hooks
	void Paint();
};
