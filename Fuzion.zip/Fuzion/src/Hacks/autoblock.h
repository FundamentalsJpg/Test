#pragma once

#include "../settings.h"
#include "../interfaces.h"

namespace Autoblock
{
	//Hooks
	void CreateMove(CUserCmd* cmd);
}
