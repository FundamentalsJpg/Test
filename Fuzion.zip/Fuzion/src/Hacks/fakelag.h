#pragma once

#include "../settings.h"
#include "../interfaces.h"
#include "../Hooks/hooks.h"
#include "../Utils/util.h"

namespace FakeLag
{
	//Hooks
	void CreateMove(CUserCmd* cmd);
};
