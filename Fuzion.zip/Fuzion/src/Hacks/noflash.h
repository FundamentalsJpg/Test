#pragma once

#include "../interfaces.h"
#include "../settings.h"

namespace Noflash
{
	//Hooks
	void FrameStageNotify(ClientFrameStage_t stage);
}
