#pragma once

#include "../settings.h"
#include "../interfaces.h"
#include "../Utils/entity.h"
#include "../Utils/math.h"

namespace AutoDefuse
{
	//Hooks
	void CreateMove(CUserCmd* cmd);
};
