#pragma once

#include "../settings.h"

namespace DisablePostProcessing
{
	void BeginFrame();
}
