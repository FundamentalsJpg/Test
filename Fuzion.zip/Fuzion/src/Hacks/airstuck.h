#pragma once

#include "../settings.h"
#include "../interfaces.h"

namespace Airstuck
{
	//Hooks
	void CreateMove(CUserCmd* cmd);
}
