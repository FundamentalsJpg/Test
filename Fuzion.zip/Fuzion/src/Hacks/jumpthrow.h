#pragma once

#include "../interfaces.h"
#include "../settings.h"
#include "../Utils/entity.h"

namespace JumpThrow
{
	//Hooks
	void CreateMove(CUserCmd* cmd);
}
