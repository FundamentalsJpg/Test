#pragma once

#include "../interfaces.h"
#include "../settings.h"

namespace AutoStrafe
{
	//Hooks
	void CreateMove(CUserCmd* cmd);
}
